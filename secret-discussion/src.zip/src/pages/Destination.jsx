import React from 'react'
import Navbar from '../Components/Navbar'
const Destination = () => {
  return (
    <>
    <Navbar />
    <h1>des</h1>
    </>
  )
}

export default Destination